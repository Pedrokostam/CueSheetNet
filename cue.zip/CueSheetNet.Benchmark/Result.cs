﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CueSheetNet.Benchmark
{
    internal record Result(string Keyword, string? SecondKeyword, string Value, string? Suffix)
    {
    }
}

# CueSheetNet
CueSheetNet is a .NET library used for reading, modifying and saving cuesheet (.cue).
It supports all popular styles of cuesheet (from the most popular single file to EAC-style multiple file with postgaps)

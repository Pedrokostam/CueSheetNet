﻿namespace CueSheetNet;

public interface IParentSheet
{
    CueSheet ParentSheet { get; }
}
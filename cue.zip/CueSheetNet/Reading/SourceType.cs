﻿
namespace CueSheetNet.Reading;

public enum SourceType
{
    None,
    File,
    Stream,
    Bytes,
    String,
}

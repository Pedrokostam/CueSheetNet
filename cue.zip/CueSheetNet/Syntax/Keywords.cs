﻿namespace CueSheetNet.Syntax
{
    internal enum Keywords
    {
        INVALID,
        REM,
        PERFORMER,
        TITLE,
        FILE,
        CDTEXTFILE,
        TRACK,
        FLAGS,
        INDEX,
        POSTGAP,
        PREGAP,
        ISRC,
        CATALOG
    }
}
